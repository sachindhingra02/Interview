package com.threatreSeating.constant;

public class TheaterConstants {
	public static final String SUCCESS = "SUCCESS";
	public static final String FAIL = "FAIL";
	public static final String DIFF_ROW = "Call to split party";
}
